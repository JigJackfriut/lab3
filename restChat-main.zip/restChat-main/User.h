#ifndef USER_H
#define USER_H

#include <string>

struct User {
    std::string username;
    std::string email;
    std::string password;
};

#endif // USER_H
